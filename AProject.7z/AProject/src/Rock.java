import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

public class Rock extends GameObject {
	
	// ======= Important Objects ======= \\
	public Point2D position;
	private BufferedImage rockImage;
	private String name;
	
	
	// ======= Rock Constructor ======= \\

	public Rock(Point2D initialPosition, World world){
		super(initialPosition, world);
		this.position = initialPosition;
		this.name="rock";
		this.setName("rock");
	
	}	

	public Point2D returnPosition(){
		return this.position;
	}
	
	@Override
	public void timePassed() {
		// TODO Auto-generated method stub.
		updatePosition();
	}

	@Override
	public void die() {
		// TODO Auto-generated method stub.
		
	}

	@Override
	public void setIsPaused(boolean isPaused) {
		// TODO Auto-generated method stub.
		
	}

	@Override
	public boolean getIsPaused() {
		// TODO Auto-generated method stub.
		return false;
	}
	
	public void updatePosition() {
		
		Point2D newPosition = new Point2D.Double(100,100);
		this.setCenterPoint(newPosition);
	}
}